# == Schema Information
#
# Table name: cat_rental_requests
#
#  id         :integer          not null, primary key
#  cat_id     :integer          not null
#  start_date :date             not null
#  end_date   :date             not null
#  status     :string           default("PENDING"), not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class CatRentalRequest < ApplicationRecord
  validates :cat_id, :start_date, :end_date, :status, presence: true
  validates :status, inclusion: { in: ['PENDING', 'APPROVED', 'DENIED'] }

  belongs_to :cat,
    primary_key: :id,
    foreign_key: :cat_id,
    class_name: :Cat

  def overlapping_requests
    CatRentalRequest.where('( (start_date <= ? AND end_date <= ?) OR
                              (start_date >= ? AND end_date >=  ?) ) AND
                               cat_id = ? AND id != ?',
                               self.start_date, self.end_date,
                               self.start_date, self.end_date,
                               self.cat_id, self.id)
  end

  def overlapping_approved_requests
    overlapping_requests.where("status = 'APPROVED'")
  end

  def does_not_overlap_approved_request
    !overlapping_approved_requests.exists?
  end

  def approve!
    if does_not_overlap_approved_request
      request = self
      CatRentalRequest.transaction do
        request.status = 'APPROVED'
        request.save!

        overlapping_pending_requests.each do |overlapping_request|
          overlapping_request.deny!
          overlapping_request.save
        end
      end
    else
      puts 'something bad happened'
    end
  end

  def overlapping_pending_requests
    overlapping_requests.where("status = 'PENDING'")
  end

  def deny!
    self.status = 'DENIED'
  end

end
