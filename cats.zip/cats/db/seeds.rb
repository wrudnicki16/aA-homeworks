# == Schema Information
#
# Table name: cat_rental_requests
#
#  id         :integer          not null, primary key
#  cat_id     :integer          not null
#  start_date :date             not null
#  end_date   :date             not null
#  status     :string           default("PENDING"), not null
#  created_at :datetime         not null
#  updated_at :datetime         not null

Cat.destroy_all
CatRentalRequest.destroy_all

names = ['Bruce', 'Wyatt', 'Carl', 'Garfield', 'Doreamon', 'Hello Kitty', 'Catbert']
sexes = ['M', 'F']

5.times do
  Cat.create(
    birth_date: '2015/01/20',
    color: Cat::COLORS.sample,
    name: names.sample,
    sex: sexes.sample,
    description: 'askldalksdjalskdjalskjdaslkdjalksdjaslkdjaslk'
  )
end
puts "Created 5 cats"

CatRentalRequest.create(cat_id: 1, start_date: '2018/01/10', end_date: '2018/01/12', status: 'PENDING')
CatRentalRequest.create(cat_id: 2, start_date: '2018/01/22', end_date: '2018/01/25', status: 'PENDING')
CatRentalRequest.create(cat_id: 2, start_date: '2018/01/23', end_date: '2018/01/25', status: 'PENDING')

puts "Created 3 rental requests"
